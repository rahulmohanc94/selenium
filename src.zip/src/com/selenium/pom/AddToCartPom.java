package com.selenium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AddToCartPom {
	 public static WebElement element;



	 public static WebElement popup_click(WebDriver driver,WebDriverWait waitelement)
	    {
	    element = waitelement.until(ExpectedConditions.elementToBeClickable(By.name("button")));
	    return element;
	    }
	    
	  /*  public static WebElement Signin_Link(WebDriver driver)
	    {
	                    element = driver.findElement(By.className("login"));
	                    return element;
	    }
	    
	    public static WebElement Email(WebDriver driver)
	    {
	                    element = driver.findElement(By.id("email"));
	                    return element;
	    }
	    
	    public static WebElement password(WebDriver driver)
	    {
	                    element = driver.findElement(By.id("passwd"));
	                    return element;
	    }
	    
	    public static WebElement Signin(WebDriver driver)
	    {
	                    element = driver.findElement(By.id("SubmitLogin"));
	                    return element;
	    }
	    
	    public static WebElement Addtocart(WebDriver driver)
	    {
	                    element = driver.findElement(By.linkText("Add to cart"));
	                    return element;
	    }
	    public static WebElement proceed(WebDriver driver) {
	    	element = driver.findElement(By.xpath("//div[@class='layer_cart_product_info']/span"));
	    	return element;
	    	}*/

	 final WebDriver driver;

     
     @FindBy(how = How.ID, using = "email") 
     public WebElement email;
     @FindBy(how = How.ID, using = "passwd") 
     public WebElement password;
     @FindBy(how = How.ID, using = "SubmitLogin") 
     public WebElement submit;
     @FindBy(how = How.ID, using = "search_query_top") 
     public WebElement search;
     @FindBy(how = How.NAME, using = "submit_search") 
     public WebElement submitsearch;
     @FindBy(how = How.LINK_TEXT, using = "Add to cart") 
     public WebElement addtocart;
     @FindBy(how = How.XPATH, using = "//div[@class='layer_cart_product_info']/span") 
     public WebElement proceed;
     
     public AddToCartPom(WebDriver driver)
     
     {
            this.driver = driver;

            }

	 
	 
}
