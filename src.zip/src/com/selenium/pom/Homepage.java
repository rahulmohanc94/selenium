package com.selenium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selenium.base.Testbase;

public class Homepage extends Testbase {
    public static WebElement element;

    final WebDriver driver;

    
    @FindBy(how = How.ID, using = "search_query_top") 
    public WebElement searchitem;
    @FindBy(how = How.NAME, using = "submit_search") 
    public WebElement Search_Box;

  /*  public static WebElement popup_click(WebDriver driver,WebDriverWait waitelement)
    {
    element = waitelement.until(ExpectedConditions.elementToBeClickable(By.name("button")));
    return element;
    }
    
    public static WebElement Searchitem(WebDriver driver)
    {
                    element = driver.findElement(By.id("search_query_top"));
                    return element;
    }
    
    public static WebElement Search_Box(WebDriver driver)
    {
                    element = driver.findElement(By.name("submit_search"));
                    return element;
    }*/
    
    
    public Homepage(WebDriver driver)
    
    {
           this.driver = driver;

           }
	
}
