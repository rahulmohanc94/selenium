package com.selenium.functions;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selenium.base.Testbase;
import com.selenium.pom.AddToCartPom;
import com.selenium.pom.Homepage;



public class AddToCartFunction extends Testbase {
	public static void AddToCart() throws IOException {
	
	wait = new WebDriverWait(driver, 300);
	
	//AddToCartPom.Signin_Link(driver).click();
	Properties prop = new Properties();
	InputStream input = null;

	
	
	 
		input = new FileInputStream(System.getProperty("user.dir")+
				 System.getProperty("file.separator")+"src\\com\\selenium\\config\\user.properties");
	
	
		prop.load(input);

	/*AddToCartPom.Email(driver).sendKeys(prop.getProperty("username1"));
	AddToCartPom.password(driver).sendKeys(prop.getProperty("password1"));
	AddToCartPom.Signin(driver).click();
	Homepage.Searchitem(driver).sendKeys("T-shirt");
	Homepage.Search_Box(driver).click();
	AddToCartPom.Addtocart(driver).click();
	WebElement elementnew=AddToCartPom.proceed(driver);
	if(!elementnew.equals(null))
	{
		System.out.println("added to cart");
	}*/
		
		AddToCartPom AddToCart = PageFactory.initElements(driver, AddToCartPom.class);
		
		AddToCart.email.sendKeys(prop.getProperty("username1"));
        AddToCart.password.sendKeys(prop.getProperty("password1"));
        AddToCart.submit.click();
        AddToCart.search.sendKeys("T shirt");
        AddToCart.submitsearch.click();
        AddToCart.addtocart.click();

		}
		
}

