package com.selenium.functions;


import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.selenium.base.Testbase;
import com.selenium.pom.Homepage;
import com.selenium.pom.RegistrationPom;



public class RegisterFunction extends Testbase  {
	

	public static void Registration(String email, String gender, String fname, String lname, String password,
			String dob, String company, String address1, String address2, String city, String state, String pincode,
			String phone) {
		// TODO Auto-generated method stub
		
		try{
		wait = new WebDriverWait(driver, 100);
		RegistrationPom reg = PageFactory.initElements(driver, RegistrationPom.class);
		reg.Signin_Link.click();
		String mailid = email + System.currentTimeMillis() + "@gmail.com";
		
		reg.email.sendKeys(mailid);
		reg.Submit.click();
		if (gender.equals("male")) {
			RegistrationPom.gender1(driver, wait).click();
	
		}
		else
		{
			RegistrationPom.gender2(driver, wait).click();
			
		}
		reg.fname.sendKeys(fname);
		reg.lname.sendKeys(lname);
		reg.password.sendKeys(password);
		
		Select selectDays = new Select(reg.days);
		String[] date=dob.split("/");
		selectDays.selectByValue(date[0]);
		Select selectMonths = new Select(reg.months);
		selectMonths.selectByValue(date[1]);
			Select selectYear = new Select(reg.years);
			selectYear.selectByValue(date[2]);
			try {
				Properties property = new Properties();
				
				property.setProperty("username"+i,mailid);
				property.setProperty("password"+i, password);
				
				property.store(file, "Login credentials");
				i++;
				
				} catch (FileNotFoundException e) {
				e.printStackTrace();
				} catch (Exception e) {
				e.printStackTrace();
				}
			reg.company.sendKeys(company);
			reg.address1.sendKeys(address1);
			reg.address2.sendKeys(address2);
			reg.city.sendKeys(city);
			Select selectState = new Select(reg.state);
			selectState.selectByVisibleText(state);
			
			reg.postcode.sendKeys(pincode);
			reg.mobile.sendKeys(phone);
			RegistrationPom.Submitaccount(driver, wait).click();
			
			
		
		/*RegistrationPom.Signin_Link(driver).click();
	
		
		String mailid = email + System.currentTimeMillis() + "@gmail.com";
		RegistrationPom.email(driver).sendKeys(mailid);
		Assert.assertEquals(RegistrationPom.email(driver).getAttribute("value"), mailid);
		RegistrationPom.submit(driver).click();
		
		if (gender.equals("male")) {
		
			RegistrationPom.gender1(driver, wait).click();
			
			
		}
		else

		{
			RegistrationPom.gender2(driver, wait).click();
			
		}
		
		RegistrationPom.fname(driver).sendKeys(fname);
		Assert.assertEquals(RegistrationPom.fname(driver).getAttribute("value"), fname);
		
		RegistrationPom.lname(driver).sendKeys(lname);
		Assert.assertEquals(RegistrationPom.lname(driver).getAttribute("value"), lname);
		RegistrationPom.password(driver).sendKeys(password);
		Assert.assertEquals(RegistrationPom.password(driver).getAttribute("value"), password);
		Select selectDays = new Select(RegistrationPom.day(driver));
		String[] date=dob.split("/");
		selectDays.selectByValue(date[0]);
		
	Select selectMonths = new Select(RegistrationPom.month(driver));
	selectMonths.selectByValue(date[1]);
		Select selectYear = new Select(RegistrationPom.year(driver));
		selectYear.selectByValue(date[2]);
		
		
		try {
			Properties property = new Properties();
			
			property.setProperty("username"+i,mailid);
			property.setProperty("password"+i, password);
			
			property.store(file, "Login credentials");
			i++;
			
			} catch (FileNotFoundException e) {
			e.printStackTrace();
			} catch (Exception e) {
			e.printStackTrace();
			}
		

		RegistrationPom.company(driver).sendKeys(company);
		Assert.assertEquals(RegistrationPom.company(driver).getAttribute("value"), company);
				
	RegistrationPom.address1(driver).sendKeys(address1);
	Assert.assertEquals(RegistrationPom.address1(driver).getAttribute("value"), address1);
		RegistrationPom.address2(driver).sendKeys(address2);
		Assert.assertEquals(RegistrationPom.address2(driver).getAttribute("value"), address2);
		RegistrationPom.city(driver).sendKeys(city);
		Assert.assertEquals(RegistrationPom.city(driver).getAttribute("value"), city);
		Select selectState = new Select(RegistrationPom.state(driver));
		selectState.selectByVisibleText(state);
		RegistrationPom.postcode(driver).sendKeys(pincode);
		Assert.assertEquals(RegistrationPom.postcode(driver).getAttribute("value"), pincode);
		
		
		RegistrationPom.mobile(driver).sendKeys(phone);
		Assert.assertEquals(RegistrationPom.mobile(driver).getAttribute("value"), phone);
		RegistrationPom.Submitaccount(driver, wait).click();*/
		WebElement element=driver.findElement(By.className("icon-user"));
		 if (element != null) {
			
		
		System.out.println("Registration success ");
		
		}
		 else
		 {
			 System.out.println("Registration fail");
		 
		}
		
		}
	
	catch(Exception e)
	{
		
	}
	}
}
