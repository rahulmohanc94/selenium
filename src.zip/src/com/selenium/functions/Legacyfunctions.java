package com.selenium.functions;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.selenium.base.Testbase;
import com.selenium.pom.AddToCartPom;
import com.selenium.pom.Homepage;



public class Legacyfunctions extends Testbase {

	public static void Searchitem(String item) {
		// TODO Auto-generated method stub
		try{
			


			
			wait = new WebDriverWait(driver, 300);
			//Homepage.popup_click(driver,wait).click();
			
		/*Homepage.Searchitem(driver).sendKeys(item);
		Assert.assertEquals(Homepage.Searchitem(driver).getAttribute("value"), item);
		
		Homepage.Search_Box(driver).click();*/
			Homepage SearchItem = PageFactory.initElements(driver, Homepage.class);
			
			SearchItem.searchitem.sendKeys(item);
			SearchItem.Search_Box.click();
		WebElement element=driver.findElement(By.linkText("Printed Chiffon Dress"));
		 if (element != null) {
			
		
		System.out.println("success search");
		
		}
		 else
		 {
			 System.out.println("search fail");
		 
		}
		}
		catch (Exception e) {
			// TODO: handle exception
			
		}
		

}
}
