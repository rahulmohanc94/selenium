package com.selenium.functions;


import java.io.IOException;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selenium.base.Testbase;
import com.selenium.pom.RegistrationPom;



public class GenericFunctionlib extends Testbase {

	public static void openBrowser(String url, String browser) 
	{
		try{
		if(browser.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", ".\\driver\\chromedriver.exe");
			driver=new ChromeDriver();
			driver.get(url);//reading url
			
			wait = new WebDriverWait(driver, 100);
			
			//RegistrationPom.popup_click(driver, wait).click();
			String selectLinkOpeninNewTab = Keys.chord(Keys.CONTROL,Keys.RETURN); 
            driver.findElement(By.name("button")).sendKeys(selectLinkOpeninNewTab);
            
            ArrayList<String> handle= new ArrayList<String>(driver.getWindowHandles());//Return a string of alphanumeric window handle
     
     
            driver.switchTo().window(handle.get(1)); 
		}
		else if (browser.equalsIgnoreCase("ie")) { 
			 
			  
		 
			  System.setProperty("webdriver.ie.driver", ".\\driver\\IEDriverServer.exe");
		 
			  driver = new InternetExplorerDriver();
			  driver.get(url);//reading url
		}
		}
		catch(Exception e){
			e.printStackTrace();
		}
				
	
		
		
		
	}
	public static void divisionWithException() {
		int i = 5 / 0;
	}
	public static void closeBrowser()
	{
		driver.quit();
	}
}
