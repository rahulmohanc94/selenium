package com.selenium.script;

import java.io.IOException;


import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.selenium.base.Testbase;
import com.selenium.functions.GenericFunctionlib;
import com.selenium.functions.Legacyfunctions;
import com.selenium.util.TestUtil;

public class SearchItems extends Testbase {
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=false;
	static int count=-1;
	String url;
	String browser;
	@Parameters({"url","browser"})
	@BeforeTest(alwaysRun=true) 
	public void checkTestSkip(String url, String browser){
		initialize();
		if(!TestUtil.isTestCaseRunnable(suiteAxls,this.getClass().getSimpleName())){
			
	
			throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
		}
		this.url=url;
		this.browser=browser;
	}
	@Test(priority=4,description="print4")
	public void four()
	{
		System.out.println("four");
	}

	@Test(priority=0,/*expectedExceptions=ArithmeticException.class,*/dataProvider="Searchitemdata")
	public void Searchitemsmethod(String searchitemsvalue) throws IOException
	{
	
		GenericFunctionlib.openBrowser(url,browser);
		
		Legacyfunctions.Searchitem(searchitemsvalue);
		//GenericFunctionlib.divisionWithException();
		GenericFunctionlib.closeBrowser();
		
		isTestPass=true;
	
	}
@Test(priority=2, enabled=false)
public void two()
{
	System.out.println("two");
}

@Test(priority=1,description="print1")
public void one()
{
	System.out.println("one");
}

@DataProvider	
public Object[][] Searchitemdata(){
	return TestUtil.getData(suiteAxls, this.getClass().getSimpleName()) ;

}

@AfterTest
public void reportTestResult(){
	if(isTestPass)
		TestUtil.reportDataSetResult(suiteAxls, "Test Cases", TestUtil.getRowNum(suiteAxls,this.getClass().getSimpleName()), "PASS");
	else
		TestUtil.reportDataSetResult(suiteAxls, "Test Cases", TestUtil.getRowNum(suiteAxls,this.getClass().getSimpleName()), "FAIL");

}

@AfterMethod
public void reportDataSetResult(){
	if(skip)
		TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count+2, "SKIP");
	else if(fail){
		isTestPass=false;
		TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count+2, "FAIL");
	}
	else
		TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count+2, "PASS");
	
	skip=false;
	fail=false;
	driver.quit();

}

}
