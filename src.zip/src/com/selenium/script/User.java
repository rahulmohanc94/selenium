package com.selenium.script;

import java.io.IOException;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.selenium.base.RetryAnalyzer;
import com.selenium.base.Testbase;
import com.selenium.functions.AddToCartFunction;
import com.selenium.functions.GenericFunctionlib;
import com.selenium.functions.RegisterFunction;
import com.selenium.util.TestUtil;

public class User extends Testbase {
	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=false;
	static int count=-1;
	String url;
	String browser;
	@Parameters({"url","browser"})
	@BeforeTest(alwaysRun=true) 
	public void checkTestSkip(String url, String browser){
		initialize();
		if(!TestUtil.isTestCaseRunnable(suiteAxls,this.getClass().getSimpleName())){
			
	
			throw new SkipException("Skipping Test Case"+this.getClass().getSimpleName()+" as runmode set to NO");//reports
		}
		this.url=url;
		this.browser=browser;
	}
	@Test(retryAnalyzer = RetryAnalyzer.class,dataProvider="Searchitemdata",expectedExceptions=ArithmeticException.class)
	public void UserRegistration(String email,String gender,String fname,String lname,String password,String dob,String company,String address1,String address2,String city,String state,String pincode,String phone) throws IOException
	{
	
		GenericFunctionlib.openBrowser(url,browser);
		
		RegisterFunction.Registration(email, gender, fname, lname, password, dob, company, address1, address2, city, state, pincode, phone);
		GenericFunctionlib.divisionWithException();
		GenericFunctionlib.closeBrowser();
		Assert.assertEquals("", "");
		isTestPass=true;
	
	
	}

@Test(dependsOnMethods={"UserRegistration"})
public void AddToCartmethod() throws IOException
{
try{
	GenericFunctionlib.openBrowser(url,browser);
	AddToCartFunction.AddToCart();;
	GenericFunctionlib.closeBrowser();
	
	isTestPass=true;
}
catch(Exception er)
{
	System.out.println("Exception Occured-"+er);
	//System.out.println("Error in method '" + method );
}
}
	@DataProvider	
	public Object[][] Searchitemdata(){
		return TestUtil.getData(suiteAxls, this.getClass().getSimpleName()) ;

	}

	@AfterTest
	public void reportTestResult(){
		if(isTestPass)
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases", TestUtil.getRowNum(suiteAxls,this.getClass().getSimpleName()), "PASS");
		else
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases", TestUtil.getRowNum(suiteAxls,this.getClass().getSimpleName()), "FAIL");

	}

	@AfterMethod
	public void reportDataSetResult(){
		if(skip)
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count+2, "SKIP");
		else if(fail){
			isTestPass=false;
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count+2, "FAIL");
		}
		else
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count+2, "PASS");
		
		skip=false;
		fail=false;
		driver.quit();

	}
}


